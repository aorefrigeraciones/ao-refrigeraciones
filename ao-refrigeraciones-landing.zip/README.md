# AO Refrigeraciones – Landing estática

Lista para publicar en **Vercel**.

## Publicar en 3 pasos
1) https://vercel.com → **Add New → Project → Import** → arrastrá este ZIP.
2) Vercel va a crear una URL pública (ej. `https://ao-refrigeraciones-landing.vercel.app`).
3) En **Settings → Domains**, agregá `aorefrigeraciones.com.ar` y seguí las instrucciones.

### Editar WhatsApp
Abrí `index.html` y cambiá la variable `phoneNumber` por tu número con +54.

---
Generado: 2025-10-09T16:01:16.920961Z
